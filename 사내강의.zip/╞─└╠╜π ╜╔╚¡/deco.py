

def outer(func):
    def inner(*args, **kwargs):
        print("함수가 실행됩니다")
        return func(*args, **kwargs)
    return inner